create function addtournoi(nompar character varying, datepar date, lieupar character varying)
  returns integer
language plpgsql
as $$
BEGIN
	INSERT INTO tounoi (nom, date, lieu) VALUES (nomPar, datePar, lieuPar);
	RETURN 0;
END;
$$;

alter function addtournoi(varchar, date, varchar)
  owner to lrolan;

