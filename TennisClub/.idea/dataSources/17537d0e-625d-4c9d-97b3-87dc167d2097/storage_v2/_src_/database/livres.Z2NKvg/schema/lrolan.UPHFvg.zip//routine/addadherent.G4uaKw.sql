create function addadherent(nompar character varying, prenompar character varying, adressepar character varying, telephonepar character varying, emailpar character varying, passwordpar character varying)
  returns integer
language plpgsql
as $$
BEGIN
	INSERT INTO adherent (nom, prenom, adresse, telephone, email, password) VALUES (nomPar, prenomPar, adressePar, telephonePar, emailPar, digest(passwordPar, 'sha224'));
	RETURN 0;
END;
$$;

alter function addadherent(varchar, varchar, varchar, varchar, varchar, varchar)
  owner to lrolan;

