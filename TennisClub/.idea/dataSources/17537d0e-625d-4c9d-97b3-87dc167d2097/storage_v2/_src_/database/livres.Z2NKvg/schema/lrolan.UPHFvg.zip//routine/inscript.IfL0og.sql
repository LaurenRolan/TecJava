create function inscript(nompar character varying, prenompar character varying, adressepar character varying, cppar numeric, villepar character varying, payspar character varying)
  returns integer
language plpgsql
as $$
DECLARE 
	code_client integer;
BEGIN
    SELECT code INTO STRICT code_client FROM clients WHERE nom = nomPar 
    		AND prenom = prenomPar AND adresse = adressePar AND
    		cp = cpPar AND ville = villePar AND pays = paysPar;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
             INSERT INTO clients (nom, prenom, adresse, cp, ville, pays)
             		VALUES (nomPar, prenomPar, adressePar,cpPar, villePar, paysPar)
             		RETURNING code INTO code_client;
             RETURN code_client;
    RETURN 0;
END;
$$;

alter function inscript(varchar, varchar, varchar, numeric, varchar, varchar)
  owner to lrolan;

