create function inscription(nompar character varying, prenompar character varying, adressepar character varying, cppar character, villepar character varying, payspar character varying)
  returns integer
language plpgsql
as $$
DECLARE 
	code_client integer;
BEGIN
    SELECT code INTO code_client FROM clients WHERE nom = nomPar
    		AND prenom = prenomPar AND adresse = adressePar;
    IF FOUND THEN code_client := 0;
    ELSE
       INSERT INTO clients (nom, prenom, adresse, cp, ville, pays)
          VALUES (DEFAULT, nomPar, prenomPar, adressePar,cpPar, villePar, paysPar)
          RETURNING code INTO code_client;
    END IF;
    RETURN code_client;

END;
$$;

alter function inscription(varchar, varchar, varchar, char, varchar, varchar)
  owner to lrolan;

